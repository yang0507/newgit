package com.firefox.mybatis.test;

import java.util.List;

import org.junit.Test;

import com.firefox.mybatis.dao.Conjuserdao;
import com.firefox.mybatis.dao.Juserdao;
import com.firefox.mybatis.domain.Conjuser;
import com.firefox.mybatis.domain.Juser;

public class JuserTest {
	@Test
	public void selectJuserByName() {
		List<Juser> list =Juserdao.selectJuserByName("test");
		for (Juser juser : list) {
			System.out.println(juser.getJid()+"  "+juser.getJusername()+"  "+juser.getJupassword());
		}
	}
}
