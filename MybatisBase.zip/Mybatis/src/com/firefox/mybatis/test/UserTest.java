package com.firefox.mybatis.test;

import java.util.List;

import org.junit.Test;

import com.firefox.mybatis.dao.Userdao;
import com.firefox.mybatis.domain.User;

public class UserTest {
	
	@Test
	public void addUserTest() {
		User user = new User();
		user.setUsername("����");;
		user.setUpassword("8888");
		try {
			int i = Userdao.AddUser(user);
			System.out.println(i);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateUserTest() {
		User user = new User();
		user.setId(10);
		user.setUsername("��˼˼");;
		user.setUpassword("88888888");
		try {
			int i = Userdao.UpdateUser(user);
			System.out.println(i);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void deleteUserTest() {
		Userdao.deleteUser(2);
	}
	@Test
	public void selectUserAll() {
		List<User> list =Userdao.selectUserAll();
		for(User user : list) {
			System.out.println(user.getId()+"  "+user.getUsername()+"  "+user.getUpassword());
		}
	}
	@Test
	public void  selectUserById() {
		User user = Userdao.selectUserById(3);
		System.out.println(user.getId());
		System.out.println(user.getUsername());
		System.out.println(user.getUpassword());
	}
	@Test
	public void selectUserByName() {
		List<User> list =Userdao.selectUserByName("test");
		for(User user : list) {
			System.out.println(user.getId()+"  "+user.getUsername()+"  "+user.getUpassword());
		}
	}
}
