package com.firefox.mybatis.test;

import java.util.List;

import org.junit.Test;

import com.firefox.mybatis.dao.Conjuserdao;
import com.firefox.mybatis.domain.Conjuser;

public class ConjuserTest {
	@Test
	public void selectJuserByNameCon() {
		List<Conjuser> list =Conjuserdao.selectJuserByNameCon("test");
		for (Conjuser conjuser : list) {
			System.out.println(conjuser.getJid()+"  "+conjuser.getJusername()+"  "+conjuser.getJupassword());
		}
	}
}
