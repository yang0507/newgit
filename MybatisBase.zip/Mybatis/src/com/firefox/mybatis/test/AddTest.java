package com.firefox.mybatis.test;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;

import com.firefox.mybatis.domain.User;

public class AddTest {
	private static Logger LOG = Logger.getLogger(AddTest.class);
	public static void main(String[] args) {
		String resource = "mybatis-config.xml";
		InputStream in = null;
		SqlSession session = null;
		try {			
			in=Resources.getResourceAsStream(resource);
			SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);
			session = factory.openSession();
			User user = new User();
			user.setUsername("test");
			user.setUpassword("test");
			session.insert("com.firefox.mybatis.domain.UserMapper.addUser", user);
			session.commit();
			int i = user.getId();
			System.out.println(i);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOG.error(e);
		}finally {
			if(session!=null) {
				session.close();
			}
		}
	}
}
