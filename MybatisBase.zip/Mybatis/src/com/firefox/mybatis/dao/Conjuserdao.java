package com.firefox.mybatis.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.firefox.mybatis.domain.Conjuser;
import com.firefox.mybatis.utils.SqlSessionFactoryUtils;

public class Conjuserdao {
	private static Logger LOG = Logger.getLogger(Conjuserdao.class);
	public static List<Conjuser> selectJuserByNameCon(String name){
		List<Conjuser> list = null;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			list = session.selectList("com.firefox.mybatis.mappers.ConjuserMapper.selectConjuserByName", name);
		} catch (Exception e) {
			LOG.error(e);
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return list;
	}
}
