package com.firefox.mybatis.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.firefox.mybatis.domain.User;
import com.firefox.mybatis.utils.SqlSessionFactoryUtils;


public class Userdao {
	private static Logger LOG = Logger.getLogger(Userdao.class);
	public static int AddUser(User user) {
		int i = 0;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			session.insert("com.firefox.mybatis.mappers.UserMapper.addUser", user);
			i = user.getId();
			session.commit();
		} catch (Exception e) {
			LOG.error(e);
			session.rollback();
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return i;
	}
	public static int UpdateUser(User user) {
		int i=0;
		SqlSession session = null;
		session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
		session.update("com.firefox.mybatis.mappers.UserMapper.updateUser", user);
		i=user.getId();
		session.commit();
		if(session!=null) {
			session.close();			
		}
		return i;
	}
	public static int deleteUser(int id) {
		int i = 0;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			i = session.delete("com.firefox.mybatis.mappers.UserMapper.deleteUser", id);
			session.commit();
		} catch (Exception e) {
			LOG.error(e);
			session.rollback();
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return i;
	}
	public static List<User> selectUserAll() {
		List<User> list = null;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			list = session.selectList("com.firefox.mybatis.mappers.UserMapper.selectUserAll");
		} catch (Exception e) {
			LOG.error(e);
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return list;
	}
	public static User selectUserById(int id) {
		User user = null;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			user = session.selectOne("com.firefox.mybatis.mappers.UserMapper.selectUserById", id);
		} catch (Exception e) {
			LOG.error(e);
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return user;
		
	}
	public static List<User> selectUserByName(String name){
		List<User> list = null;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			list = session.selectList("com.firefox.mybatis.mappers.UserMapper.selectUserByName", name);
		} catch (Exception e) {
			LOG.error(e);
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return list;
	}
}
