package com.firefox.mybatis.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.firefox.mybatis.domain.Juser;
import com.firefox.mybatis.utils.SqlSessionFactoryUtils;

public class Juserdao {
	private static Logger LOG = Logger.getLogger(Juserdao.class);
	public static List<Juser> selectJuserByName(String name){
		List<Juser> list = null;
		SqlSession session = null;
		try {
			session = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
			list = session.selectList("com.firefox.mybatis.mappers.JuserMapper.selectJuserByName", name);
		} catch (Exception e) {
			LOG.error(e);
			throw new RuntimeException();
		} finally {
			if(session!=null) {
				session.close();			
			}
		}
		return list;
	}
}
