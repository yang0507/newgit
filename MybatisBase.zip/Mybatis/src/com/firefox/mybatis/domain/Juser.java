package com.firefox.mybatis.domain;

public class Juser {
	private int jid;
	private String jusername;
	private String jupassword;
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public String getJusername() {
		return jusername;
	}
	public void setJusername(String jusername) {
		this.jusername = jusername;
	}
	public String getJupassword() {
		return jupassword;
	}
	public void setJupassword(String jupassword) {
		this.jupassword = jupassword;
	}
}
